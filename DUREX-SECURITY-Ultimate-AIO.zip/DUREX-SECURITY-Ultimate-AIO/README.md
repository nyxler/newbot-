# DUREX SECURITY — Ultimate AIO Bot (Starter Build)

A Python `discord.py` starter combining a dual prefix/slash command system and an interactive, category-based Help Desk inspired by the requested reference projects.

## Included and implemented
- Prefix commands: `?help`, `?ping`, `?prefix`, `?serverinfo`, `?botinfo`, `?userinfo`, `?avatar`, `?modules`
- Slash commands: `/help`, `/ping`, `/prefix`, `/serverinfo`
- Interactive Help Desk select menu with categories for Security, Logs/Moderation, Community, Utilities, Dashboard and Owner System
- `?logs channel #channel` and `?logs status` configuration saved in JSON
- Honest status messages for security modules not implemented yet
- Environment-variable token configuration

## Not yet implemented
The Help Desk documents the planned direction; it does not mean those modules are active. Advanced AntiNuke, AntiRaid, event logging, tickets, giveaways, leveling, backup/restore, verification and OAuth2 dashboard still require implementation and testing.

## Setup (Windows)
1. Install Python 3.10 or newer.
2. Extract the ZIP and open a terminal in this folder.
3. Create a virtual environment:
   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   pip install -r requirements.txt
   ```
4. Copy `.env.example` to `.env` and enter your bot token in `DISCORD_TOKEN`.
5. In the Discord Developer Portal, enable **Message Content Intent** and **Server Members Intent** if needed. Invite the bot with `bot` and `applications.commands` scopes, plus the permissions needed for features you enable.
6. Start the bot:
   ```powershell
   python main.py
   ```

## Notes
- Never commit `.env` or share your token. If a token was exposed, reset it in the Developer Portal.
- Slash commands may take a little time to appear globally after sync.
- The current prefix is configured in `.env`; the `?prefix` command displays it but does not change it yet.
- This is a starter build, not a completed production security bot.
- Reference repositories must be checked for their current licenses before reusing their source code.
