import os
import logging
import discord
from discord.ext import commands
from dotenv import load_dotenv

from cogs.helpdesk import HelpDesk
from cogs.utility import Utility
from cogs.configuration import Configuration

load_dotenv()
logging.basicConfig(level=logging.INFO, format="[%(asctime)s] [%(levelname)s] %(name)s: %(message)s")

TOKEN = os.getenv("DISCORD_TOKEN", "").strip()
PREFIX = os.getenv("BOT_PREFIX", "?").strip() or "?"

intents = discord.Intents.default()
intents.guilds = True
intents.members = True
intents.message_content = True
intents.moderation = True
intents.voice_states = True

class DurexSecurity(commands.Bot):
    def __init__(self):
        super().__init__(
            command_prefix=commands.when_mentioned_or(PREFIX),
            intents=intents,
            help_command=None,
            case_insensitive=True,
        )

    async def setup_hook(self):
        await self.add_cog(HelpDesk(self))
        await self.add_cog(Utility(self))
        await self.add_cog(Configuration(self))
        try:
            synced = await self.tree.sync()
            logging.info("Synced %s global slash commands.", len(synced))
        except Exception:
            logging.exception("Slash-command sync failed.")

    async def on_ready(self):
        logging.info("Logged in as %s (ID: %s)", self.user, self.user.id)
        logging.info("Serving %s guild(s).", len(self.guilds))
        await self.change_presence(
            activity=discord.Activity(
                type=discord.ActivityType.watching,
                name=f"{PREFIX}help | protecting servers"
            )
        )

bot = DurexSecurity()

@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandNotFound):
        return
    if isinstance(error, commands.MissingPermissions):
        await ctx.reply("🛡️ You don't have permission to use that command.", mention_author=False)
        return
    if isinstance(error, commands.BotMissingPermissions):
        await ctx.reply("⚠️ I am missing the Discord permissions required for that action.", mention_author=False)
        return
    if isinstance(error, commands.MissingRequiredArgument):
        await ctx.reply(f"⚠️ Missing argument: `{error.param.name}`.", mention_author=False)
        return
    logging.exception("Command error", exc_info=error)
    await ctx.reply("❌ Something went wrong while running that command.", mention_author=False)

if not TOKEN:
    raise SystemExit("Missing DISCORD_TOKEN. Copy .env.example to .env and add your bot token.")

bot.run(TOKEN)
