import json
from pathlib import Path
import discord
from discord.ext import commands

DATA_DIR = Path("data")
DATA_DIR.mkdir(exist_ok=True)
CONFIG_FILE = DATA_DIR / "guild_config.json"

def read_config():
    try:
        return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError):
        return {}

def write_config(data):
    CONFIG_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")

class Configuration(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.group(name="logs", invoke_without_command=True)
    @commands.guild_only()
    async def logs(self, ctx):
        await ctx.send("Use `?logs channel #channel` or `?logs status`.")

    @logs.command(name="channel")
    @commands.has_guild_permissions(manage_guild=True)
    async def logs_channel(self, ctx, channel: discord.TextChannel):
        data = read_config()
        guild_config = data.setdefault(str(ctx.guild.id), {})
        guild_config["log_channel_id"] = channel.id
        write_config(data)
        await ctx.reply(f"📜 Log channel set to {channel.mention}.", mention_author=False)

    @logs.command(name="status")
    @commands.guild_only()
    async def logs_status(self, ctx):
        config = read_config().get(str(ctx.guild.id), {})
        channel_id = config.get("log_channel_id")
        channel = ctx.guild.get_channel(channel_id) if channel_id else None
        await ctx.reply(f"📜 Log destination: {channel.mention if channel else 'Not configured'}", mention_author=False)

    @commands.command(name="security")
    async def security(self, ctx, action: str = "status"):
        if action.lower() != "status":
            await ctx.reply("This starter build currently supports `?security status`. Other security actions are not implemented yet.", mention_author=False)
            return
        await ctx.reply("🛡️ Security status: core starter online. Advanced AntiNuke/AntiRaid protections are planned and are not active in this build.", mention_author=False)

    @commands.command(name="antinuke")
    async def antinuke(self, ctx, action: str = "status"):
        await ctx.reply("🛡️ AntiNuke status: scaffold only; active destructive-event detection is not implemented in this starter build.", mention_author=False)

async def setup(bot):
    await bot.add_cog(Configuration(bot))
