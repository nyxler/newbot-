import discord
from discord.ext import commands
from discord import app_commands

class Utility(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.prefix_value = "?"

    @commands.command(name="ping")
    async def ping_prefix(self, ctx):
        """Show bot latency."""
        ms = round(self.bot.latency * 1000)
        await ctx.reply(f"🔹 Pong! `{ms} ms`", mention_author=False)

    @app_commands.command(name="ping", description="Show bot latency")
    async def ping_slash(self, interaction: discord.Interaction):
        ms = round(self.bot.latency * 1000)
        await interaction.response.send_message(f"🔹 Pong! `{ms} ms`", ephemeral=True)

    @commands.command(name="prefix")
    async def prefix_prefix(self, ctx):
        """Show the current command prefix."""
        await ctx.reply(f"🔹 Current prefix: `{self.prefix_value}`", mention_author=False)

    @app_commands.command(name="prefix", description="Show the current command prefix")
    async def prefix_slash(self, interaction: discord.Interaction):
        await interaction.response.send_message(f"🔹 Current prefix: `{self.prefix_value}`", ephemeral=True)

    @commands.command(name="serverinfo", aliases=["si", "guildinfo"])
    @commands.guild_only()
    async def serverinfo_prefix(self, ctx):
        """Show information about this server."""
        guild = ctx.guild
        embed = discord.Embed(title=f"🌐 {guild.name}", color=0x4C8DFF)
        if guild.icon:
            embed.set_thumbnail(url=guild.icon.url)
        embed.add_field(name="Server ID", value=f"`{guild.id}`", inline=True)
        embed.add_field(name="Members", value=f"`{guild.member_count}`", inline=True)
        embed.add_field(name="Created", value=discord.utils.format_dt(guild.created_at, style="D"), inline=False)
        embed.add_field(name="Owner", value=f"<@{guild.owner_id}>", inline=True)
        embed.set_footer(text="DUREX SECURITY • Server Information")
        await ctx.reply(embed=embed, mention_author=False)

    @app_commands.command(name="serverinfo", description="Show information about this server")
    @app_commands.guild_only()
    async def serverinfo_slash(self, interaction: discord.Interaction):
        guild = interaction.guild
        if guild is None:
            await interaction.response.send_message("This command can only be used in a server.", ephemeral=True)
            return
        embed = discord.Embed(title=f"🌐 {guild.name}", color=0x4C8DFF)
        if guild.icon:
            embed.set_thumbnail(url=guild.icon.url)
        embed.add_field(name="Server ID", value=f"`{guild.id}`", inline=True)
        embed.add_field(name="Members", value=f"`{guild.member_count}`", inline=True)
        embed.add_field(name="Created", value=discord.utils.format_dt(guild.created_at, style="D"), inline=False)
        embed.add_field(name="Owner", value=f"<@{guild.owner_id}>", inline=True)
        embed.set_footer(text="DUREX SECURITY • Server Information")
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @commands.command(name="botinfo")
    async def botinfo(self, ctx):
        """Show bot information."""
        embed = discord.Embed(title="🛡️ DUREX SECURITY", description="Ultimate AIO Discord bot starter.", color=0x4C8DFF)
        embed.add_field(name="Latency", value=f"`{round(self.bot.latency * 1000)} ms`")
        embed.add_field(name="Servers", value=f"`{len(self.bot.guilds)}`")
        embed.add_field(name="Library", value=f"`discord.py {discord.__version__}`")
        await ctx.reply(embed=embed, mention_author=False)

    @commands.command(name="userinfo")
    @commands.guild_only()
    async def userinfo(self, ctx, member: discord.Member = None):
        """Show information about a member."""
        member = member or ctx.author
        embed = discord.Embed(title=f"👤 {member}", color=0x4C8DFF)
        embed.set_thumbnail(url=member.display_avatar.url)
        embed.add_field(name="User ID", value=f"`{member.id}`", inline=True)
        embed.add_field(name="Joined", value=discord.utils.format_dt(member.joined_at, style="D") if member.joined_at else "Unknown", inline=True)
        embed.add_field(name="Created", value=discord.utils.format_dt(member.created_at, style="D"), inline=True)
        await ctx.reply(embed=embed, mention_author=False)

    @commands.command(name="avatar")
    async def avatar(self, ctx, member: discord.User = None):
        """Show a user's avatar."""
        member = member or ctx.author
        embed = discord.Embed(title=f"🖼️ {member}'s avatar", color=0x4C8DFF)
        embed.set_image(url=member.display_avatar.url)
        await ctx.reply(embed=embed, mention_author=False)

    @commands.command(name="modules")
    async def modules(self, ctx):
        """Show implementation status of major modules."""
        embed = discord.Embed(title="🧩 DUREX SECURITY Modules", color=0x4C8DFF)
        embed.add_field(name="Starter commands", value="Help Desk, ping, prefix, serverinfo, botinfo, userinfo, avatar", inline=False)
        embed.add_field(name="Planned modules", value="AntiNuke, AntiRaid, advanced logs, tickets, backup/restore, giveaways, leveling, dashboard", inline=False)
        embed.set_footer(text="Planned does not mean implemented.")
        await ctx.reply(embed=embed, mention_author=False)

async def setup(bot):
    await bot.add_cog(Utility(bot))
