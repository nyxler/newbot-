import discord
from discord.ext import commands
from discord import app_commands

ACCENT = 0x4C8DFF
CRIMSON = 0xD64255
EMOJI = {
    "home": "🏠", "security": "🛡️", "logs": "📜", "moderation": "🔨",
    "community": "🎟️", "utility": "⚙️", "dashboard": "🌐", "owner": "👑",
    "status": "🔹", "back": "◀️", "next": "▶️"
}

PAGES = {
    "home": {
        "title": "DUREX SECURITY • HELP DESK",
        "description": (
            "Welcome to the **Ultimate AIO Control Center**.\n"
            "Choose a category from the menu below to explore commands.\n\n"
            "🔹 **Prefix:** `?` (configurable)\n"
            "🔹 **Slash commands:** `/help`, `/ping`, `/prefix`, `/serverinfo`\n"
            "🛡️ **Security-first design** with modular features."
        ),
        "fields": [
            ("🛡️ Security & AntiNuke", "Protection commands and planned security modules."),
            ("📜 Logs & Moderation", "Logging configuration and moderation tools."),
            ("🎟️ Community", "Tickets, welcome, giveaways, leveling and suggestions."),
            ("⚙️ Utilities & Setup", "Server information, bot status and configuration."),
        ],
    },
    "security": {
        "title": "🛡️ SECURITY & ANTINUKE",
        "description": "**Available now**\n`?security status` — show module status\n`?antinuke status` — show AntiNuke implementation status\n\n**Planned modules**\nAnti mass-ban/kick • Channel/role protection • Permission escalation detection • Webhook monitoring • AntiRaid • Verification • Incident response\n\nSecurity actions must be configured and tested before production use.",
        "fields": [],
    },
    "logs": {
        "title": "📜 LOGS & MODERATION",
        "description": "**Available now**\n`?logs channel #channel` — set the log destination\n`?logs status` — view current log destination\n`?ban @user [reason]` — ban a member\n`?kick @user [reason]` — kick a member\n\n**Planned log categories**\nSecurity • Messages • Members • Moderation • Voice • Server audit events",
        "fields": [],
    },
    "community": {
        "title": "🎟️ COMMUNITY MODULES",
        "description": "**Planned modules**\nTickets and transcripts • Welcome/farewell • AutoRole • Giveaways • Leveling and XP • Suggestions and voting • Anti-alt checks • Verification and quarantine",
        "fields": [],
    },
    "utility": {
        "title": "⚙️ UTILITIES & CONFIGURATION",
        "description": "**Available now**\n`?help` • `?ping` • `?prefix` • `?serverinfo` • `?botinfo` • `?userinfo @member` • `?avatar [member]` • `?modules`\n\n**Slash commands**\n`/help` • `/ping` • `/prefix` • `/serverinfo`",
        "fields": [],
    },
    "dashboard": {
        "title": "🌐 WEB DASHBOARD",
        "description": "**Planned integration**\nDiscord OAuth2 login • Guild selection • Security settings • Log viewer • Backup controls.\n\nThe web dashboard is not included as a live service in this starter build.",
        "fields": [],
    },
    "owner": {
        "title": "👑 OWNER & ACCESS CONTROL",
        "description": "**Planned access model**\nBot Owner • Five Extra Owner slots • Guild-owner security permissions • Trusted-user controls.\n\nDo not store your bot token in code or share it with anyone.",
        "fields": [],
    },
}

class HelpCategorySelect(discord.ui.Select):
    def __init__(self):
        options = [
            discord.SelectOption(label="Home", value="home", emoji="🏠", description="Return to the main Help Desk"),
            discord.SelectOption(label="Security & AntiNuke", value="security", emoji="🛡️", description="Security modules and protection"),
            discord.SelectOption(label="Logs & Moderation", value="logs", emoji="📜", description="Logs and moderation commands"),
            discord.SelectOption(label="Community", value="community", emoji="🎟️", description="Tickets and community features"),
            discord.SelectOption(label="Utilities & Setup", value="utility", emoji="⚙️", description="Utilities and configuration"),
            discord.SelectOption(label="Web Dashboard", value="dashboard", emoji="🌐", description="Dashboard integration plan"),
            discord.SelectOption(label="Owner System", value="owner", emoji="👑", description="Owner and access-control plan"),
        ]
        super().__init__(placeholder="Choose a Help Desk category…", min_values=1, max_values=1, options=options)

    async def callback(self, interaction: discord.Interaction):
        await self.view.show_page(interaction, self.values[0])

class HelpDeskView(discord.ui.View):
    def __init__(self, owner_id: int, timeout: float = 180):
        super().__init__(timeout=timeout)
        self.owner_id = owner_id
        self.add_item(HelpCategorySelect())

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("This Help Desk belongs to the user who opened it. Run `?help` to open your own.", ephemeral=True)
            return False
        return True

    async def show_page(self, interaction: discord.Interaction, page_key: str):
        page = PAGES.get(page_key, PAGES["home"])
        embed = discord.Embed(
            title=page["title"],
            description=page["description"],
            color=CRIMSON if page_key == "security" else ACCENT,
        )
        embed.set_footer(text="DUREX SECURITY • Ultimate AIO • Help Desk")
        for name, value in page.get("fields", []):
            embed.add_field(name=name, value=value, inline=False)
        if interaction.response.is_done():
            await interaction.edit_original_response(embed=embed, view=self)
        else:
            await interaction.response.edit_message(embed=embed, view=self)

class HelpDesk(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="help", aliases=["helpdesk", "commands"])
    async def helpdesk_prefix(self, ctx):
        """Open the interactive Help Desk."""
        embed = discord.Embed(
            title=PAGES["home"]["title"],
            description=PAGES["home"]["description"],
            color=ACCENT,
        )
        for name, value in PAGES["home"]["fields"]:
            embed.add_field(name=name, value=value, inline=False)
        embed.set_footer(text="Select a category below • Menu expires after 3 minutes")
        await ctx.reply(embed=embed, view=HelpDeskView(ctx.author.id), mention_author=False)

    @app_commands.command(name="help", description="Open the DUREX SECURITY Help Desk")
    async def help_slash(self, interaction: discord.Interaction):
        embed = discord.Embed(
            title=PAGES["home"]["title"],
            description=PAGES["home"]["description"],
            color=ACCENT,
        )
        for name, value in PAGES["home"]["fields"]:
            embed.add_field(name=name, value=value, inline=False)
        await interaction.response.send_message(embed=embed, view=HelpDeskView(interaction.user.id), ephemeral=True)

async def setup(bot):
    await bot.add_cog(HelpDesk(bot))
